/* mj2_to_metadata.h */
/* Dump MJ2, JP2 metadata (partial so far) to xml file */
/* Contributed to Open JPEG by Glenn Pearson, U.S. National Library of Medicine */

#define BOOL int
#define FALSE 0
#define TRUE 1

#include "meta_out.h"
